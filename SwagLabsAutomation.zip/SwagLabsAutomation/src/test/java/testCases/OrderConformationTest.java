package testCases;

import org.testng.annotations.Test;

import base.BaseTest;
import controller.AddToCartPage;
import controller.OrderConformationPage;

public class OrderConformationTest extends BaseTest {

	
OrderConformationPage order= new OrderConformationPage();
	
	
	@Test(groups= {"smoke"})
	public void Validate_Order_conformation_page() throws Throwable {
		
		order.verify_Order_Status();
	}
}
