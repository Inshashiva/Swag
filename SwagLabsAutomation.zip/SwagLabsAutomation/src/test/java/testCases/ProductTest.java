package testCases;

import org.testng.annotations.Test;

import base.BaseTest;
import controller.CheckoutPage;
import controller.ProductPage;

public class ProductTest extends BaseTest{

	
ProductPage productpage= new ProductPage();
	
	
	@Test(groups= {"smoke"})
	public void Validate_Product_page() throws Throwable {
		
	  productpage.verify_Sauce_Labs_Backpack_Product();
	}
}
