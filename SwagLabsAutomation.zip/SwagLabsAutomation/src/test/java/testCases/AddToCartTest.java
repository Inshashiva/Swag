package testCases;

import org.testng.annotations.Test;

import base.BasePage;
import base.BaseTest;
import controller.AddToCartPage;
import controller.LoginPage;

public class AddToCartTest extends BaseTest {

	
	BasePage base = new BasePage();
	
	AddToCartPage addToCart= new AddToCartPage();
	
	
	@Test(groups= {"smoke"})
	public void Validate_add_to_cart() throws Throwable {
		
		addToCart.verify_addToCart_page();
	}
}
