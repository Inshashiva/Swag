package testCases;

import org.testng.annotations.Test;

import base.BaseTest;
import controller.AddToCartPage;
import controller.CheckoutPage;

public class CheckoutTest extends BaseTest {
	
CheckoutPage checkoutpage= new CheckoutPage();
	
	
	@Test(groups= {"smoke"})
	public void Validate_Checkout_page() throws Throwable {
		
	  checkoutpage.Verify_Checkout_Page_Details();
	}

}
