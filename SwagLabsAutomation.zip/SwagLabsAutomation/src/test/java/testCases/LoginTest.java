package testCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import base.BasePage;
import base.BaseTest;
import controller.LoginPage;

public class LoginTest extends BaseTest{
	
	BasePage base = new BasePage();
	LoginPage LoginPage = new LoginPage();
	
	@Test(groups= {"smoke"})
	public void ValidateLoginWithValidCredentials() throws Throwable {
		
		LoginPage.validate_login_functionality_with_valid_credentials();
	}

	@Test(groups= {"smoke"})
	public void ValidateLoginWithInvalidValidCredentials() throws Throwable {
		
		LoginPage.validate_login_functionality_with_Invalid_credentials();
	}



}
