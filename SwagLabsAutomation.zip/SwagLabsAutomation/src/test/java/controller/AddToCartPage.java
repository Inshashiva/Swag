package controller;

import base.BasePage;

public class AddToCartPage extends BasePage{
 
	private static String fleeceJacket = "xpath;//*[@class='btn btn_secondary btn_small btn_inventory'];fleeceJacket";
	private static String cartCTA = "xpath;//*[@class='shopping_cart_link'];cartCTA";
	
	
	public void verify_addToCart_page() throws Throwable {
		
		isElementPresent(fleeceJacket);
		click(fleeceJacket);
		isElementPresent(cartCTA);
		click(cartCTA);
	}


	
	
}

