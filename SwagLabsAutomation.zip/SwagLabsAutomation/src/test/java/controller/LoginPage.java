package controller;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BasePage;

public class LoginPage extends BasePage {

	
	private static String UserName = "xpath;//*[@id='user-name'];UserName";
	private static String Password = "xpath;//*[@id='password'];password";
	private static String Submit = "xpath;//*[@id='login-button'];Submit";
	
	
	
	public void validate_login_functionality_with_valid_credentials() throws Throwable {
		
		clear(UserName);
		type(UserName,"problem_user");
		clear(Password);
		type(Password,"secret_sauce");
		clear(Submit);
		type(Submit,"click");
		
		
	}
public void validate_login_functionality_with_Invalid_credentials() throws Throwable {
		
		clear(UserName);
		type(UserName,"problem_user");
		clear(Password);
		type(Password,"secret");
		clear(Submit);
		type(Submit,"click");
		
		
	 
		
	}
}
