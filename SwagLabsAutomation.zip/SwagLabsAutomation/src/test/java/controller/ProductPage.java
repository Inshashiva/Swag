package controller;

import base.BasePage;

public class ProductPage extends BasePage {

	
	private static String Backpack = "xpath;(//*[@class='inventory_item_name'])[1];Backpack";
	
	
	public void verify_Sauce_Labs_Backpack_Product() throws Throwable {
		
		
		isElementPresent(Backpack);
		click(Backpack);
	}
}

