package controller;

import base.BasePage;

public class CheckoutPage extends BasePage{

	
	private static String btnButton = "xpath;//*[@class='btn btn_action btn_medium checkout_button'];btnButton";
	private static String FirstName = "xpath;//*[@id='first-name'];FirstName";
	private static String LastName = "xpath;//*[@id='last-name'];LastName";
	private static String zipcode= "xpath;//*[@id='postal-code'];zipcode";
	private static String continueButton= "xpath;//*[@id='continue'];continueButton";
	private static String productName= "xpath;//*[@class='inventory_item_name'];productName";
	private static String summaryValue= "xpath;(//*[@class='summary_value_label'])[1];summaryValue";
	private static String totalAmount= "xpath;//*[@class='summary_subtotal_label'];totalAmount";
	private static String Finish= "xpath;//*[@class='btn_action cart_button'];Finish";
	
	public void Verify_Checkout_Page_Details() throws Exception {
		
		click(btnButton);
		clear(FirstName);
		type(FirstName,"Siva");
		clear(LastName);
		type(LastName,"s");
		clear(zipcode);
		type(zipcode,"12234");
		click(continueButton);
		String productname =getLocator(productName).getText();
		String summaryvalue =getLocator(summaryValue).getText();
		String totalamount =getLocator(totalAmount).getText();
		isElementPresent(Finish);
		click(Finish);
		
	}
}

