package controller;

import base.BasePage;

public class OrderConformationPage extends BasePage {
	
	private static String OrderConformation = "xpath;//*[@class='complete-header'];OrderConformation";
	
	
	public void verify_Order_Status() throws Throwable {
		
		isElementPresent(OrderConformation);
		
		click(OrderConformation);
	}

}
