package base;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver;

public class BasePage {
	public WebElement element ;
	public WebDriver driver;
	
	public void click(String locator)throws Exception {
		
 WebElement element =getLocator(locator);
		if (element!=null) {
			JavascriptExecutor js = (JavascriptExecutor)driver;
			
			js.executeScript("argument[0].click();", element);
			
			
			
		}

	}

	protected WebElement getLocator(String locator) {
		
		return null;
	}
	
	
	
	public void clear(String locator)throws Exception {
		
		 WebElement element =getLocator(locator);
				if (element!=null) {
					
					element.sendKeys(Keys.chord(Keys.CONTROL,"a",Keys.DELETE));
				}
	
	
	}
	
	
	public String gettext(String locator)throws Exception {
		
		 WebElement element =getLocator(locator);
		 String value="";
				if (element!=null) {
					
					value=element.getText();
					System.out.println(value);
				}
					
					return value;
				}
	
	
	public String getAttributeValue(String locator,String attribute)throws Exception {
		
		 WebElement element =getLocator(locator);
		 String value="";
				if (element!=null) {
					
					value=element.getAttribute(attribute);
					System.out.println(value);
				}
					
					return value;
				}

	public void type(String locator,String value)throws Exception {
		
		 WebElement element =getLocator(locator);
		 
				if (element!=null) {
					element.sendKeys(value);
					
					if(locator.endsWith("_password")) {
						
						
						getLocatorName(locator);
					}
					
				}
						
					}
				public Boolean isElementPresent(String locator)throws Exception {
					
					 WebElement element =getLocator(locator);
					 
					 element.isDisplayed();
					 
							
					getLocatorName(locator);
					return null;
								
			
				}

	private void getLocatorName(String locator) {
		
		
	}
	
	
	
	
	
	
	
	
	

}
