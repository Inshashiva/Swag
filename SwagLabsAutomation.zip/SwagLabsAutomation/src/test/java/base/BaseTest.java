package base;

import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BaseTest {
	
	public void browserLaunch() {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\nandu\\eclipse-workspace_Swaglabs\\SwagLabsAutomation\\Container\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.saucedemo.com/");

		
	}
	
}
